﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Xml.Linq;
using MessageBox = System.Windows.MessageBox;

namespace SpotXY
{
    class SpravceSpotu
    {

        public ObservableCollection<Spot> Spoty { get; set; }

        private SpotMaker spotMaker;
        private List<Spot> spoty;
        public SpravceSpotu()
        {
            spoty = new List<Spot>();
        }
        
        public void Nacti()
        {
            spotMaker = new SpotMaker();
            spotMaker.Nacti();
            spoty.Add(new Spot(spotMaker.filename, spotMaker.StredX, spotMaker.StredY, spotMaker.elapsed_timeX, spotMaker.elapsed_timeY));
            Spoty = new ObservableCollection<Spot>(spoty);
        }

        public void ZobrazBmpP()
        {
            spotMaker.ZobrazBmpP();
        }

        public void Vypocitej()
        {
            spotMaker.Vypocitej();
            spoty.RemoveAt(spoty.Count - 1);
            spoty.Add(new Spot(spotMaker.filename, spotMaker.StredX, spotMaker.StredY, spotMaker.elapsed_timeX, spotMaker.elapsed_timeY));
            Spoty = new ObservableCollection<Spot>(spoty);
        }

        public void ZobrazBmp()
        {
            spotMaker.ZobrazBmp();
        }

        public void OtevriTab()
        {
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // přednastavené jméno souboru
            dlg.DefaultExt = ".xml"; // přednastavená přípona souboru
            dlg.Filter = "Xml documents (.xml)|*.xml"; // filter soubotů podle přípony

            // ukaž dialogové okno pro otevření souboru
            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {
                // otevření dokumentu
                string filename = dlg.FileName;

                // Vyjímka pro úspěšné načtení správného dokumentu 
                try
                {
                    XDocument.Load(filename);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Chyba - načtěte prosím .xml soubor.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                var dokument = XDocument.Load(filename);

                // převod xml souboru do listu pro zobrazení základní tabulky
                spoty = dokument.Root.Descendants("spot")
                    .Select(p => new Spot
                    {
                        NazevObr = p.Attribute("obrazek").Value,
                        SX = Convert.ToInt32(p.Element("stredX").Value),
                        SY = Convert.ToInt32(p.Element("stredY").Value),
                        CasX = Convert.ToInt64(p.Element("casX").Value),
                        CasY = Convert.ToInt64(p.Element("casY").Value)
                    }).ToList();

                // chybové hlášení pro načtení špatného nebo poškozeného xml souboru 
                bool isEmpty = !spoty.Any();
                if (isEmpty)
                {
                    System.Windows.MessageBox.Show("Zdrojový list je prázdný", "Chyba - .xml soubor není pravděpodobně správný (v pořádku).", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                // převod listu do kolekce, která slouží jako zdroj pro zobrazení základní tabulky
                Spoty = new ObservableCollection<Spot>(spoty);
            }
        }

        public void ZapisTab()
        {
            XDocument dokument = new XDocument(
            new XDeclaration("1.0", "UTF-8", null),
            new XElement("spoty",
                    spoty.Select(u => new XElement("spot",
                            new XAttribute("obrazek", u.NazevObr),
                            new XElement("stredX", u.SX),
                            new XElement("stredY", u.SY),
                            new XElement("casX", u.CasX),
                            new XElement("casY", u.CasY))
                    ))
            );

            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "Document";
            dlg.DefaultExt = ".xml";
            dlg.Filter = "XML-File | *.xml";
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                dokument.Save(dlg.FileName);
            }
        }


    }
}

