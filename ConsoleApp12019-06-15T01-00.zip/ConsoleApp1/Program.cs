﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            
            string filename = "Filter_O_D__=_0_14.bmp";
            // Create a new bitmap.
            Bitmap bmp = new Bitmap(filename, true);

            // Lock the bitmap's bits.  
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            System.Drawing.Imaging.BitmapData bmpData =
                bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
                bmp.PixelFormat);

            


            // Get the address of the first line.
            IntPtr ptr = bmpData.Scan0;

            // Declare an array to hold the bytes of the bitmap.
            int bytes = Math.Abs(bmpData.Stride) * bmp.Height;
            byte[] rgbValues = new byte[bytes];

            // Copy the RGB values into the array.
            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

            /*
            // Set every third value to 255. A 24bpp bitmap will look red.  
            for (int counter = 2; counter < rgbValues.Length; counter += 3)
                rgbValues[counter] = 255;
           

            // Copy the RGB values back to the bitmap
            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

            // Unlock the bits.
            bmp.UnlockBits(bmpData);
             */

            
            Console.WriteLine("Array-Length: " + rgbValues.Length.ToString());
            Console.WriteLine(rgbValues.ToList()[1171615]);
            byte maxValue = rgbValues.Max();
            int maxIndex = rgbValues.ToList().IndexOf(maxValue);
            Console.WriteLine("Array-maxValue: " + maxValue.ToString());
            Console.WriteLine("Array-maxIndex: " + maxIndex.ToString());
            Console.WriteLine("Array-maxIndex, radek: " + (maxIndex/1600).ToString());
            Console.WriteLine("Array-maxIndex, sloupec: " + (maxIndex%1600).ToString());

            Console.ReadKey();

            /* 

           foreach (var item in rgbValues)
         {
             Console.Write(item.ToString() + " ");                
         }
          Console.ReadKey();




    Console.WriteLine("bmp.PixelFormat: " + bmp.PixelFormat.ToString());
    Console.WriteLine("bmp.Height: " + bmp.Height.ToString());
    Console.WriteLine("bmpData.Stride: " + bmpData.Stride.ToString());

    Console.WriteLine("int bytes: " + bytes.ToString());
   Console.WriteLine("Array-Length: " + rgbValues.Length.ToString());

   Console.ReadKey();



   byte maxValue = mybytearray.Max();
   int maxIndex = mybytearray.ToList().IndexOf(maxValue);
   byte minValue = mybytearray.Min();
   int minIndex = mybytearray.ToList().IndexOf(minValue);
   Console.WriteLine(" ", maxIndex);
   Console.WriteLine(filename + ": ");
   Console.WriteLine("Image-Width: " + img.Width.ToString()) ;
   Console.WriteLine("Image-Height: " + img.Height.ToString());
   Console.WriteLine("Array-maxValue: " + maxValue.ToString());
   Console.WriteLine("Array-maxIndex: " + maxIndex.ToString());
   Console.WriteLine("Array-minValue: " + minValue.ToString());
   Console.WriteLine("Array-minIndex: " + minIndex.ToString());
   Console.WriteLine("Array-Length: " + mybytearray.Length.ToString());
   Console.ReadKey();

   */
        }
    }
}
