﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] mybytearray;
            System.Drawing.Image img = System.Drawing.Image.FromFile("Filter_O_D__=_0_0.bmp", true);
            var stream = new MemoryStream();
            img.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            mybytearray = stream.ToArray();
            Console.WriteLine("Hello world!!!");
            Console.ReadKey();
        }
    }
}
