﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] mybytearray;
            System.Drawing.Image img = System.Drawing.Image.FromFile("2.bmp", true);
            var stream = new MemoryStream();
            img.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            mybytearray = stream.ToArray();



            
            foreach (var item in mybytearray)
            {
                Console.Write(item.ToString());
                Console.Write(" ");
            }

            byte maxValue = mybytearray.Max();
            int maxIndex = mybytearray.ToList().IndexOf(maxValue);
            Console.WriteLine(maxIndex);
            Console.ReadKey();
        }
    }
}
