﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpotXY
{
    // logika programu


    public class SpotMaker
    {

        public string filename { get; set; }        // jmeno souboru obrazu
        public int StredX { get; set; }             // x souradnice vypocteneho středu
        public int StredY { get; set; }             // y souřadnice vypočteného středu
        public long elapsed_timeX { get; set; }     // výsledný čas potřebný pro výpočet souřadnice X
        public long elapsed_timeY { get; set; }     // výsledný čas potřebný pro výpočet souřadnice Y

        private Bitmap bmp;                 // obrazek, na kterem pozdeji probihaji zmeny

        private Bitmap bmpP;             // uchovava puvodni obrazek beze zmen

        private string fileN;

        const int SPOT_AREA = 31;       // uvadi velikost ctverce spotu pro vypocet

        private int ItoX(int x)         // preved index byte pole a dej X souradnici
        {
            return x % 1600;
        }

        private int ItoY(int y)         // preved index byte pole a dej Y souradnici
        {
            return y / 1600;
        }

        private int XYtoI(int x, int y)     // preved souradnice XY na index byte pole
        {
            return (y * 1600) + x;
        }

        private void giveFname()      // dej soubor obrazu
        {

            
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Obrázek";
            dlg.DefaultExt = ".bmp";
            dlg.Filter = "Bitmap Image(.bmp)|*.bmp";

            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {
                fileN = dlg.FileName;
                filename = dlg.SafeFileName;
            }
            
        }

        private int giveSX(int StartX, int StartY, byte[] rgbValues)    //funkce pro vypocet x-ove souřadnice středu
        {
            //vypocet nejjasnejsiho sloupce
            int[] ArrSumSl = new int[SPOT_AREA];   // Pole sum jednotlivých sloupců
            int[] ValuesSl = new int[SPOT_AREA];   // Pole Values jednoho sloupce

            for (int j = 0; j < SPOT_AREA; j++)
            {
                for (int i = 0; i < SPOT_AREA; i++)
                {
                    int I = XYtoI(StartX + j, StartY + i);
                    ValuesSl[i] = rgbValues.ToList()[I];
                }
                ArrSumSl[j] = ValuesSl.Sum();
            }

            int maxOfArrSumSl = ArrSumSl.Max();     // Hodnota souctu Values pixelu nejjasnejsiho soupce
            int posOfmaxOfArrSumSl = ArrSumSl.ToList().IndexOf(maxOfArrSumSl);    // Pozice nejjasnejsiho sloupce v poli ArrSumSl
            StredX = posOfmaxOfArrSumSl + StartX;    // Hodnota x-ové souřadnice středu
            return StredX;
        }
        private int giveSY(int StartX, int StartY, byte[] rgbValues)    //funkce pro vypocet y-ove souřadnice středu
        {
            //vypocet nejjasnejsiho radku
            int[] ArrSumRa = new int[SPOT_AREA];   // Pole sum jednotlivých radků
            int[] ValuesRa = new int[SPOT_AREA];   // Pole Values jednoho radku

            for (int l = 0; l < SPOT_AREA; l++)
            {
                for (int k = 0; k < SPOT_AREA; k++)
                {
                    int J = XYtoI(StartX + k, StartY + l);
                    ValuesRa[k] = rgbValues.ToList()[J];
                }
                ArrSumRa[l] = ValuesRa.Sum();
            }

            int maxOfArrSumRa = ArrSumRa.Max();     // Hodnota souctu Values pixelu nejjasnejsiho radku
            int posOfmaxOfArrSumRa = ArrSumRa.ToList().IndexOf(maxOfArrSumRa);    // Pozice nejjasnejsiho radku v poli ArrSumRa
            StredY = posOfmaxOfArrSumRa + StartY;    // Hodnota y-ové souřadnice středu
            return StredY;
        }


        public void Nacti()
        {
            giveFname();
            bmp = new Bitmap(fileN, true);
            bmpP = new Bitmap(fileN, true);
        }

        public void Vypocitej()
        {
            // Lock the bitmap's bits.  
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            System.Drawing.Imaging.BitmapData bmpData =
            bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
            bmp.PixelFormat);

            // Get the address of the first line.
            IntPtr ptr = bmpData.Scan0;

            // Declare an array to hold the bytes of the bitmap.
            int bytes = Math.Abs(bmpData.Stride) * bmp.Height;
            byte[] rgbValues = new byte[bytes];

            // Copy the RGB values into the array.
            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

            //nejjasnejsi pixel souboru
            byte maxJasValue = rgbValues.Max();
            int maxJasI = rgbValues.ToList().IndexOf(maxJasValue);
            int maxJasX = ItoX(maxJasI);
            int maxJasY = ItoY(maxJasI);

            //starting point spotu 
            int StartX = maxJasX - SPOT_AREA / 2;
            int StartY = maxJasY - SPOT_AREA / 2;

            //VYPOCET SOURADNICE X STREDU 
            var stopwatchX = new Stopwatch();
            stopwatchX.Start();      // zapnuti stopek
            StredX = giveSX(StartX, StartY, rgbValues);
            stopwatchX.Stop();  // vypnuti stopek
            elapsed_timeX = stopwatchX.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty X souradnice

            //VYPOCET SOURADNICE Y STREDU
            var stopwatchY = new Stopwatch();
            stopwatchY.Start();      // zapnuti stopek
            StredY = giveSY(StartX, StartY, rgbValues);
            stopwatchY.Stop();  // vypnuti stopek
            elapsed_timeY = stopwatchY.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty Y souradnice

            // Nakresli kriz  
            for (int counter1 = StredX; counter1 < rgbValues.Length; counter1 += 1600)
                rgbValues[counter1] = 125;
            for (int counter2 = StredY * 1600; counter2 < (StredY + 1) * 1600; counter2++)
                rgbValues[counter2] = 125;

            // Copy the RGB values back to the bitmap
            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

            // Unlock the bits.
            bmp.UnlockBits(bmpData);

        }

        public void ZobrazBmp()          //Zobrazeni bmp
        {
            Form form = new Form();
            form.ClientSize = new Size(1600,1200);
            form.Text = filename;
            form.Show();
            PictureBox pb = new PictureBox();
            pb.Image = bmp;
            pb.Size = form.Size;
            pb.SizeMode = PictureBoxSizeMode.Normal;
            form.Controls.Add(pb);
        }

        public void ZobrazBmpP()          //Zobrazeni bmpP - puvodniho bez kříže
        {
            Form form = new Form();
            form.ClientSize = new Size(1600, 1200);
            form.Text = filename;
            form.Show();
            PictureBox pb = new PictureBox();
            pb.Image = bmpP;
            pb.Size = form.Size;
            pb.SizeMode = PictureBoxSizeMode.Normal;
            form.Controls.Add(pb);
        }


    }
}

/*

         // Vyjímka pro úspěšné načtení správného dokumentu 
         try
         {
             XDocument.Load(filename);
         }
         catch (Exception ex)
         {
             MessageBox.Show(ex.Message, "Chyba - načtěte prosím .xml soubor.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
             return;
         }

         var auta = XDocument.Load(filename);

         // převod xml souboru do listu pro zobrazení základní tabulky
         autaZakladni = auta.Root.Descendants("auto")
             .Select(p => new Auto
             {
                 Model = p.Attribute("model").Value,
                 Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                 Cena = Convert.ToDouble(p.Element("cena").Value),
                 DPH = Convert.ToDouble(p.Element("dph").Value),

             }).ToList();

         foreach (Auto a in autaZakladni)
         {
             a.CenaSDPH = (a.Cena + a.Cena * (a.DPH / 100));
         }

         // chybové hlášení pro načtení špatného nebo poškozeného xml souboru 
         bool isEmpty = !autaZakladni.Any();
         if (isEmpty)
         {
             MessageBox.Show("Zdrojový list je prázdný", "Chyba - .xml soubor není pravděpodobně správný (v pořádku).", MessageBoxButton.OK, MessageBoxImage.Exclamation);
             return;
         }

         // převod listu do kolekce, která slouží jako zdroj pro zobrazení základní tabulky
         Auta = new ObservableCollection<Auto>(autaZakladni);
         */


