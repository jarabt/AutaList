﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace SpotXY
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {               
        private SpravceSpotu spravceSpotu = new SpravceSpotu();
               
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Nacist_Click(object sender, RoutedEventArgs e)
        {
            spravceSpotu.Nacti();
            SpotyDataGrid.ItemsSource = spravceSpotu.Spoty;
        }

        private void Zobraz_Click(object sender, RoutedEventArgs e)
        {
            spravceSpotu.ZobrazBmpP();
        }

        private void Vypocitat_Click(object sender, RoutedEventArgs e)  
        {
            spravceSpotu.Vypocitej();            
            SpotyDataGrid.ItemsSource = spravceSpotu.Spoty;
        }

        private void Kriz_Click(object sender, RoutedEventArgs e)
        {
            spravceSpotu.ZobrazBmp();
        }

        private void OtevritTab_Click(object sender, RoutedEventArgs e)
        {
            spravceSpotu.OtevriTab();            
            SpotyDataGrid.ItemsSource = spravceSpotu.Spoty;            
        }

        private void ZapsatTab_Click(object sender, RoutedEventArgs e)
        {
            spravceSpotu.ZapisTab();
        }

    }
}