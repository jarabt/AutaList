﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;
using Size = System.Drawing.Size;

namespace SpotXY
{
    // logika programu


    public class SpotMaker
    {

        public string filename { get; set; }        // jmeno souboru obrazu
        public int StredX { get; set; }             // x souradnice vypocteneho středu
        public int StredY { get; set; }             // y souřadnice vypočteného středu
        public long elapsed_timeX { get; set; }     // výsledný čas potřebný pro výpočet souřadnice X
        public long elapsed_timeY { get; set; }     // výsledný čas potřebný pro výpočet souřadnice Y

        private Bitmap bmp;                 // obrazek, na kterem pozdeji probihaji zmeny

        private Bitmap bmpP;             // uchovava puvodni obrazek beze zmen

        private string fileN;           // cesta a nazev souboru

        const int SPOT_AREA = 31;       // uvadi velikost ctverce spotu pro vypocet

        private int ItoX(int x)         // preved index byte pole a dej X souradnici
        {
            return x % 1600;
        }

        private int ItoY(int y)         // preved index byte pole a dej Y souradnici
        {
            return y / 1600;
        }

        private int XYtoI(int x, int y)     // preved souradnice XY na index byte pole
        {
            return (y * 1600) + x;
        }

        private void giveFname()      // dej soubor a cestu obrazu
        {

            
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Obrázek";
            dlg.DefaultExt = ".bmp";
            dlg.Filter = "Bitmap Image(.bmp)|*.bmp";

            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {
                fileN = dlg.FileName;
                filename = dlg.SafeFileName;
            }

        }

        private int giveSX(int StartX, int StartY, byte[] rgbValues)    //funkce pro vypocet x-ove souřadnice středu
        {
            //vypocet nejjasnejsiho sloupce
            int[] ArrSumSl = new int[SPOT_AREA];   // Pole sum jednotlivých sloupců
            int[] ValuesSl = new int[SPOT_AREA];   // Pole Values jednoho sloupce

            for (int j = 0; j < SPOT_AREA; j++)
            {
                for (int i = 0; i < SPOT_AREA; i++)
                {
                    int I = XYtoI(StartX + j, StartY + i);
                    ValuesSl[i] = rgbValues.ToList()[I];
                }
                ArrSumSl[j] = ValuesSl.Sum();
            }

            int maxOfArrSumSl = ArrSumSl.Max();     // Hodnota souctu Values pixelu nejjasnejsiho soupce
            int posOfmaxOfArrSumSl = ArrSumSl.ToList().IndexOf(maxOfArrSumSl);    // Pozice nejjasnejsiho sloupce v poli ArrSumSl
            StredX = posOfmaxOfArrSumSl + StartX;    // Hodnota x-ové souřadnice středu
            return StredX;
        }
        private int giveSY(int StartX, int StartY, byte[] rgbValues)    //funkce pro vypocet y-ove souřadnice středu
        {
            //vypocet nejjasnejsiho radku
            int[] ArrSumRa = new int[SPOT_AREA];   // Pole sum jednotlivých radků
            int[] ValuesRa = new int[SPOT_AREA];   // Pole Values jednoho radku

            for (int l = 0; l < SPOT_AREA; l++)
            {
                for (int k = 0; k < SPOT_AREA; k++)
                {
                    int J = XYtoI(StartX + k, StartY + l);
                    ValuesRa[k] = rgbValues.ToList()[J];
                }
                ArrSumRa[l] = ValuesRa.Sum();
            }

            int maxOfArrSumRa = ArrSumRa.Max();     // Hodnota souctu Values pixelu nejjasnejsiho radku
            int posOfmaxOfArrSumRa = ArrSumRa.ToList().IndexOf(maxOfArrSumRa);    // Pozice nejjasnejsiho radku v poli ArrSumRa
            StredY = posOfmaxOfArrSumRa + StartY;    // Hodnota y-ové souřadnice středu
            return StredY;
        }

        private void Zobraz(Bitmap b)          //Zobrazeni bmp
        {
            Form form = new Form();
            form.ClientSize = new Size(1600, 1200);
            form.Text = filename;
            form.Show();
            PictureBox pb = new PictureBox();
            pb.Image = b;
            pb.Size = form.Size;
            pb.SizeMode = PictureBoxSizeMode.Normal;
            form.Controls.Add(pb);
        }


        public void Nacti()
        {
            giveFname();
                        
            bmp = new Bitmap(fileN, true);
            bmpP = new Bitmap(fileN, true);

            // vyvolání vyjímky při nesprávné podobě souboru
            if (bmp.Width != 1600 || bmp.Height != 1200)
            {                
                bmp = new Bitmap("", true);
                bmpP = new Bitmap("", true);
            }
            
            
        }

        public void Vypocitej()             //vypocita a nakresli kriz 
        {
            // Uzamčení bmp  
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            System.Drawing.Imaging.BitmapData bmpData =
            bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
            bmp.PixelFormat);

            // adresa prniho radku
            IntPtr ptr = bmpData.Scan0;

            // vytvoření pole typu  byte 
            int bytes = Math.Abs(bmpData.Stride) * bmp.Height;
            byte[] rgbValues = new byte[bytes];

            // naplnění pole (jedna hodnota zastupuje 1 pixel)
            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

            //nejjasnejsi pixel souboru
            byte maxJasValue = rgbValues.Max();
            int maxJasI = rgbValues.ToList().IndexOf(maxJasValue);
            int maxJasX = ItoX(maxJasI);
            int maxJasY = ItoY(maxJasI);

            //starting point spotu 
            int StartX = maxJasX - SPOT_AREA / 2;
            int StartY = maxJasY - SPOT_AREA / 2;

            //VYPOCET SOURADNICE X STREDU 
            var stopwatchX = new Stopwatch();
            stopwatchX.Start();      // zapnuti stopek
            StredX = giveSX(StartX, StartY, rgbValues);
            stopwatchX.Stop();  // vypnuti stopek
            elapsed_timeX = stopwatchX.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty X souradnice

            //VYPOCET SOURADNICE Y STREDU
            var stopwatchY = new Stopwatch();
            stopwatchY.Start();      // zapnuti stopek
            StredY = giveSY(StartX, StartY, rgbValues);
            stopwatchY.Stop();  // vypnuti stopek
            elapsed_timeY = stopwatchY.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty Y souradnice

            // Nakresli kriz  
            for (int counter1 = StredX; counter1 < rgbValues.Length; counter1 += 1600)
                rgbValues[counter1] = 125;
            for (int counter2 = StredY * 1600; counter2 < (StredY + 1) * 1600; counter2++)
                rgbValues[counter2] = 125;

            // kopie RGB hodnot zpět do bitmapy
            System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

            // odemčení bmp
            bmp.UnlockBits(bmpData);

        }

        public void ZobrazBmp()          //Zobrazeni bmp
        {            
            Zobraz(bmp);
        }

        public void ZobrazBmpP()          //Zobrazeni bmpP - puvodniho bez kříže
        {
            Zobraz(bmpP);
        }


    }
}