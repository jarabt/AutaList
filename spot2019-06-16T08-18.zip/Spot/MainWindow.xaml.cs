﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace AutaList
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private SpotMaker spotMaker = new SpotMaker();
        public List<Spot> spoty = new List<Spot>();



        public MainWindow()
        {
            InitializeComponent();
        }



        private void Nacist_Click(object sender, RoutedEventArgs e)
        {

            spotMaker.Nacti();
            spoty.Add(new Spot(spotMaker.filename, spotMaker.StredX, spotMaker.StredY, spotMaker.elapsed_timeX, spotMaker.elapsed_timeY));
            ObservableCollection<Spot> Spoty = new ObservableCollection<Spot>(spoty);
            InitializeComponent();            
            SpotyDataGrid.ItemsSource = Spoty;
            spotMaker.ZobrazBmp();
        }



        private void Zapsat_Click(object sender, RoutedEventArgs e)
        {

        XDocument dokument = new XDocument(
        new XDeclaration("1.0", "UTF-8", null),
        new XElement("spoty",
                spoty.Select(u => new XElement("spot",
                        new XAttribute("obrazek", u.NazevObr),
                        new XElement("stredX", u.SX),
                        new XElement("stredY", u.SY),
                        new XElement("casX", u.CasX),
                        new XElement("casY", u.CasY))
                ))
        );
            dokument.Save("spoty.xml");

            /*

            // vyjímka pro výpočet bez načteného souboru
            try
            {
                spravceAut.Vypocti();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba - prosím načtěte .xml soubor.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            VysledneWindow vysledneWindow = new VysledneWindow(spravceAut);
            vysledneWindow.ShowDialog();
            */

        }

    }
}
