﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            
            string filename = "1.bmp";
            byte[] mybytearray;
            Bitmap img = new Bitmap(filename, true); ;
            var stream = new MemoryStream();
            img.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            mybytearray = stream.ToArray();

            int i = 0;

            
            foreach (var item in mybytearray)
            {
                // Console.Write(i.ToString() + ":" + item.ToString() + "   ");
                Console.Write(item.ToString() + " ");
                i += 1;
            }

            byte maxValue = mybytearray.Max();
            int maxIndex = mybytearray.ToList().IndexOf(maxValue);
            byte minValue = mybytearray.Min();
            int minIndex = mybytearray.ToList().IndexOf(minValue);
            Console.WriteLine(" ", maxIndex);
            Console.WriteLine(filename + ": ");
            Console.WriteLine("Image-Width: " + img.Width.ToString()) ;
            Console.WriteLine("Image-Height: " + img.Height.ToString());
            Console.WriteLine("Array-maxValue: " + maxValue.ToString());
            Console.WriteLine("Array-maxIndex: " + maxIndex.ToString());
            Console.WriteLine("Array-minValue: " + minValue.ToString());
            Console.WriteLine("Array-minIndex: " + minIndex.ToString());
            Console.WriteLine("Array-Length: " + mybytearray.Length.ToString());
            Console.ReadKey();
        }
    }
}
