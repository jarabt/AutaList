﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutaList
{
    // třída pro základní tabuklu
    public class Spot
    {
        public string NazevObr { get; set; }
        public int SX { get; set; }
        public int SY { get; set; }
        public long CasX { get; set; }
        public long CasY { get; set; }      
    }
}
