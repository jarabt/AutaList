﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string filename = "2.bmp";
            byte[] mybytearray;
            System.Drawing.Image img = System.Drawing.Image.FromFile(filename, true);
            var stream = new MemoryStream();
            img.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            mybytearray = stream.ToArray();



            
            foreach (var item in mybytearray)
            {
                Console.Write(item.ToString());
                Console.Write(" ");
            }

            byte maxValue = mybytearray.Max();
            int maxIndex = mybytearray.ToList().IndexOf(maxValue);
            Console.WriteLine(" ", maxIndex);
            Console.WriteLine(filename + ": ");
            Console.WriteLine("maxValue: " + maxValue.ToString());
            Console.WriteLine("maxIndex: " + maxIndex.ToString());
            Console.WriteLine("Length: " + mybytearray.Length.ToString());
            Console.ReadKey();
        }
    }
}
