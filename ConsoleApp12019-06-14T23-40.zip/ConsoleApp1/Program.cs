﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            
            string filename = "1.bmp";
            Bitmap bmp = new Bitmap(filename, true);
            byte[] myarray = new byte[bmp.Height * bmp.Width];
            int count = 0;
            
            for (int r = 0; r < bmp.Height; r++)
            {
                for (int s = 0; s < bmp.Width; s++)
                {
                    myarray[count] = bmp.GetPixel(r, s).B;
                    count++;                    
                }
            }
                                        
          foreach (var item in myarray)
         {
             Console.Write(item.ToString() + " ");                
         }
          Console.ReadKey();

            /* 

      Console.WriteLine("bmp.PixelFormat: " + bmp.PixelFormat.ToString());
      Console.WriteLine("bmp.Height: " + bmp.Height.ToString());
      Console.WriteLine("bmpData.Stride: " + bmpData.Stride.ToString());

      Console.WriteLine("int bytes: " + bytes.ToString());
     Console.WriteLine("Array-Length: " + rgbValues.Length.ToString());

     Console.ReadKey();



     byte maxValue = mybytearray.Max();
     int maxIndex = mybytearray.ToList().IndexOf(maxValue);
     byte minValue = mybytearray.Min();
     int minIndex = mybytearray.ToList().IndexOf(minValue);
     Console.WriteLine(" ", maxIndex);
     Console.WriteLine(filename + ": ");
     Console.WriteLine("Image-Width: " + img.Width.ToString()) ;
     Console.WriteLine("Image-Height: " + img.Height.ToString());
     Console.WriteLine("Array-maxValue: " + maxValue.ToString());
     Console.WriteLine("Array-maxIndex: " + maxIndex.ToString());
     Console.WriteLine("Array-minValue: " + minValue.ToString());
     Console.WriteLine("Array-minIndex: " + minIndex.ToString());
     Console.WriteLine("Array-Length: " + mybytearray.Length.ToString());
     Console.ReadKey();

     */
        }
    }
}
