﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
using System.Drawing;
using Size = System.Drawing.Size;
using System.Diagnostics;
using System.Windows.Forms;

namespace Spot
{
    class SpotMaker
    {
        int ItoX(int x)
        {
            return x % 1600;
        }

        int ItoY(int y)
        {
            return y / 1600;
        }

        int XYtoI(int x, int y)
        {
            return (y * 1600) + x;
        }

        public string filename { get; set; }
        public int StredX { get; set; }
        public int StredY { get; set; }
        public long elapsed_timeX { get; set; }
        public long elapsed_timeY { get; set; }

        public void Nacti()
        {
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Obrázek"; // přednastavené jméno souboru
            dlg.DefaultExt = ".bmp"; // přednastavená přípona souboru
            dlg.Filter = "Bitmap Image(.bmp)|*.bmp";  // filter soubotů podle přípony

            // ukaž dialogové okno pro otevření souboru
            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {

                // otevření dokumentu
                filename = dlg.FileName;
                // Create a new bitmap.
                Bitmap bmp = new Bitmap(filename, true);

                // Lock the bitmap's bits.  
                Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
                System.Drawing.Imaging.BitmapData bmpData =
                    bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
                    bmp.PixelFormat);

                // Get the address of the first line.
                IntPtr ptr = bmpData.Scan0;

                // Declare an array to hold the bytes of the bitmap.
                int bytes = Math.Abs(bmpData.Stride) * bmp.Height;
                byte[] rgbValues = new byte[bytes];

                // Copy the RGB values into the array.
                System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

                //nejjasnejsi pixel souboru
                byte maxJasValue = rgbValues.Max();
                int maxJasI = rgbValues.ToList().IndexOf(maxJasValue);
                int maxJasX = ItoX(maxJasI);
                int maxJasY = ItoY(maxJasI);
                Console.WriteLine("maxJasX: " + maxJasX);
                Console.WriteLine("maxJasY: " + maxJasY);

                //starting point spotu 31x31
                int StartX = maxJasX - 15;
                int StartY = maxJasY - 15;
                Console.WriteLine("StartX: " + StartX);
                Console.WriteLine("StartY: " + StartY);

                //VYPOCET SOURADNICE X STREDU 
                //vypocet nejjasnejsiho sloupce
                var stopwatchX = new Stopwatch();
                stopwatchX.Start();      // zapnuti stopek

                int[] ArrSumSl = new int[31];   // Pole sum jednotlivých sloupců
                int[] ValuesSl = new int[31];   // Pole Values jednoho sloupce

                for (int j = 0; j < 31; j++)
                {
                    for (int i = 0; i < 31; i++)
                    {
                        int I = XYtoI(StartX + j, StartY + i);
                        ValuesSl[i] = rgbValues.ToList()[I];
                    }
                    ArrSumSl[j] = ValuesSl.Sum();
                }

                int maxOfArrSumSl = ArrSumSl.Max();     // Hodnota souctu Values pixelu nejjasnejsiho soupce
                int posOfmaxOfArrSumSl = ArrSumSl.ToList().IndexOf(maxOfArrSumSl);    // Pozice nejjasnejsiho sloupce v poli ArrSumSl
                StredX = posOfmaxOfArrSumSl + StartX;    // Hodnota x-ové souřadnice středu
                stopwatchX.Stop();  // vypnuti stopek
                elapsed_timeX = stopwatchX.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty X souradnice

                //VYPOCET SOURADNICE Y STREDU
                //vypocet nejjasnejsiho radku
                var stopwatchY = new Stopwatch();
                stopwatchY.Start();      // zapnuti stopek

                int[] ArrSumRa = new int[31];   // Pole sum jednotlivých radků
                int[] ValuesRa = new int[31];   // Pole Values jednoho radku

                for (int l = 0; l < 31; l++)
                {
                    for (int k = 0; k < 31; k++)
                    {
                        int J = XYtoI(StartX + k, StartY + l);
                        ValuesRa[k] = rgbValues.ToList()[J];
                    }
                    ArrSumRa[l] = ValuesRa.Sum();
                }

                int maxOfArrSumRa = ArrSumRa.Max();     // Hodnota souctu Values pixelu nejjasnejsiho radku
                int posOfmaxOfArrSumRa = ArrSumRa.ToList().IndexOf(maxOfArrSumRa);    // Pozice nejjasnejsiho radku v poli ArrSumRa
                StredY = posOfmaxOfArrSumRa + StartY;    // Hodnota y-ové souřadnice středu
                stopwatchY.Stop();  // vypnuti stopek
                elapsed_timeY = stopwatchY.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty Y souradnice

                // Nakresli kriz  
                for (int counter1 = StredX; counter1 < rgbValues.Length; counter1 += 1600)
                    rgbValues[counter1] = 125;
                for (int counter2 = StredY * 1600; counter2 < (StredY + 1) * 1600; counter2++)
                    rgbValues[counter2] = 125;

                // Copy the RGB values back to the bitmap
                System.Runtime.InteropServices.Marshal.Copy(rgbValues, 0, ptr, bytes);

                // Unlock the bits.
                bmp.UnlockBits(bmpData);

                //Zobrazeni bmp
                Form form = new Form();
                form.ClientSize = new Size(1200, 1600);
                form.Show();
                PictureBox pb = new PictureBox();
                pb.Image = bmp;
                pb.Size = form.Size;
                pb.SizeMode = PictureBoxSizeMode.Zoom;
                form.Controls.Add(pb);

            }
        }
    }
}

