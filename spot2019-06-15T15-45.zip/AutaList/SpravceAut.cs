﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
using System.Drawing;
using System.Windows.Forms;
using Size = System.Drawing.Size;
using System.Diagnostics;

namespace AutaList
{
    // logika programu
    

    public class SpravceAut
    {
        int ItoX(int x)
        {
            return x % 1600;
        }

        int ItoY(int y)
        {
            return y / 1600;
        }

        int XYtoI(int x, int y)
        {
            return (y * 1600) + x;
        }



        public ObservableCollection<Auto> Auta { get; set; }                    // kolekce pro zobrazení základní tabulky 
        public ObservableCollection<PolozkaVysledku> Vysledky { get; set; }     // kolekce pro zobrazení výsledků

        private List<Auto> autaZakladni;                            // list zobrazení základní tabulky 

        public byte[] mybytearray;
        
        


        public void Nacti()
        {
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Obrázek"; // přednastavené jméno souboru
            dlg.DefaultExt = ".bmp"; // přednastavená přípona souboru
            dlg.Filter = "Bitmap Image(.bmp)|*.bmp";  // filter soubotů podle přípony

            // ukaž dialogové okno pro otevření souboru
            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {

                // otevření dokumentu
                string filename = dlg.FileName;
                // Create a new bitmap.
                Bitmap bmp = new Bitmap(filename, true);

                /*
                //Zobrazeni bmp
                Form form = new Form();
                form.ClientSize = new Size(1200,1600);
                form.Show();
                PictureBox pb = new PictureBox();
                pb.Image = bmp;
                pb.Size = form.Size;
                pb.SizeMode = PictureBoxSizeMode.Zoom;
                form.Controls.Add(pb);
                */
                
                // Lock the bitmap's bits.  
                Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
                System.Drawing.Imaging.BitmapData bmpData =
                    bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
                    bmp.PixelFormat);

                // Get the address of the first line.
                IntPtr ptr = bmpData.Scan0;

                // Declare an array to hold the bytes of the bitmap.
                int bytes = Math.Abs(bmpData.Stride) * bmp.Height;
                byte[] rgbValues = new byte[bytes];

                // Copy the RGB values into the array.
                System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);

                //nejjasnejsi pixel souboru
                byte maxJasValue = rgbValues.Max();
                int maxJasI = rgbValues.ToList().IndexOf(maxJasValue);
                int maxJasX = ItoX(maxJasI);
                int maxJasY = ItoY(maxJasI);
                Console.WriteLine("maxJasX: " + maxJasX);
                Console.WriteLine("maxJasY: " + maxJasY);

                //starting point spotu 31x31
                int StartX = maxJasX - 15;
                int StartY = maxJasY - 15;
                Console.WriteLine("StartX: " + StartX);
                Console.WriteLine("StartY: " + StartY);

                //VYPOCET SOURADNICE X STREDU 
                //vypocet nejjasnejsiho sloupce
                var stopwatchX = new Stopwatch();
                stopwatchX.Start();      // zapnuti stopek

                int[] ArrSumSl = new int[31];   // Pole sum jednotlivých sloupců
                int[] ValuesSl = new int[31];   // Pole Values jednoho sloupce

                for (int j = 0; j < 31; j++)
                {
                    for (int i = 0; i < 31; i++)
                    {
                        int I = XYtoI(StartX + j, StartY + i);
                        ValuesSl[i] = rgbValues.ToList()[I];
                    }
                    ArrSumSl[j] = ValuesSl.Sum();
                }

                int maxOfArrSumSl = ArrSumSl.Max();     // Hodnota souctu Values pixelu nejjasnejsiho soupce
                int posOfmaxOfArrSumSl = ArrSumSl.ToList().IndexOf(maxOfArrSumSl);    // Pozice nejjasnejsiho sloupce v poli ArrSumSl
                int StredX = posOfmaxOfArrSumSl + StartX;    // Hodnota x-ové souřadnice středu
                stopwatchX.Stop();  // vypnuti stopek
                long elapsed_timeX = stopwatchX.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty X souradnice

                //VYPOCET SOURADNICE Y STREDU
                //vypocet nejjasnejsiho radku
                var stopwatchY = new Stopwatch();
                stopwatchY.Start();      // zapnuti stopek

                int[] ArrSumRa = new int[31];   // Pole sum jednotlivých radků
                int[] ValuesRa = new int[31];   // Pole Values jednoho radku

                for (int l = 0; l < 31; l++)
                {
                    for (int k = 0; k < 31; k++)
                    {
                        int J = XYtoI(StartX + k, StartY + l);
                        ValuesRa[k] = rgbValues.ToList()[J];
                    }
                    ArrSumRa[l] = ValuesRa.Sum();
                }

                int maxOfArrSumRa = ArrSumRa.Max();     // Hodnota souctu Values pixelu nejjasnejsiho radku
                int posOfmaxOfArrSumRa = ArrSumRa.ToList().IndexOf(maxOfArrSumRa);    // Pozice nejjasnejsiho radku v poli ArrSumRa
                int StredY = posOfmaxOfArrSumRa + StartY;    // Hodnota y-ové souřadnice středu
                stopwatchY.Stop();  // vypnuti stopek
                long elapsed_timeY = stopwatchY.ElapsedMilliseconds;  // vysledny cas pro vypocet hodnoty Y souradnice
















                /*

                // Vyjímka pro úspěšné načtení správného dokumentu 
                try
                {
                    XDocument.Load(filename);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Chyba - načtěte prosím .xml soubor.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                var auta = XDocument.Load(filename);

                // převod xml souboru do listu pro zobrazení základní tabulky
                autaZakladni = auta.Root.Descendants("auto")
                    .Select(p => new Auto
                    {
                        Model = p.Attribute("model").Value,
                        Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                        Cena = Convert.ToDouble(p.Element("cena").Value),
                        DPH = Convert.ToDouble(p.Element("dph").Value),

                    }).ToList();

                foreach (Auto a in autaZakladni)
                {
                    a.CenaSDPH = (a.Cena + a.Cena * (a.DPH / 100));
                }

                // chybové hlášení pro načtení špatného nebo poškozeného xml souboru 
                bool isEmpty = !autaZakladni.Any();
                if (isEmpty)
                {
                    MessageBox.Show("Zdrojový list je prázdný", "Chyba - .xml soubor není pravděpodobně správný (v pořádku).", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                // převod listu do kolekce, která slouží jako zdroj pro zobrazení základní tabulky
                Auta = new ObservableCollection<Auto>(autaZakladni);
                */
            }
        }



        public void Vypocti()
        {
            List<PolozkaVysledku> vysledkyList = autaZakladni
                .Where(p => ((p.Prodano.DayOfWeek == DayOfWeek.Saturday) || (p.Prodano.DayOfWeek == DayOfWeek.Sunday)))
                .GroupBy(p => p.Model,
                (key, g) => new PolozkaVysledku
                {
                    Model = key,
                    CenaCelkem = g.Sum(p => p.Cena),
                    CenaCelkemDPH = g.Sum(p => p.CenaSDPH),
                })
                .ToList();

            // vytvoření kolekce pro zobrazení výsledků
            Vysledky = new ObservableCollection<PolozkaVysledku>(vysledkyList);
        
    
    }
        

    }

}

